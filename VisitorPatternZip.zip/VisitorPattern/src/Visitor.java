// Interface for visitors
public interface Visitor {
    void visit(RubberDuck rubberduck);
    void visit(Doll doll);
    void visit(TeddyBear teddybear);
}

// Concrete Visitor for calculating price
public class PriceVisitor implements Visitor {
    private double totalPrice = 0.0;

    @Override
    public void visit(RubberDuck rubberduck) {
        totalPrice += rubberduck.getPrice();
    }

    @Override
    public void visit(Doll doll) {
        totalPrice += doll.getPrice();
    }

    @Override
    public void visit(TeddyBear teddybear) {
        totalPrice += teddybear.getPrice();
    }

    public double getTotalPrice() {
        return totalPrice;
    }
}

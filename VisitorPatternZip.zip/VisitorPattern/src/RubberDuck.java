// RubberDuck - Concrete Element
public class RubberDuck implements Item {
    private double price;

    public RubberDuck(double price) {
        this.price = price;
    }

    public double getPrice() {
        return price;
    }

    @Override
    public void accept(Visitor visitor) {
        visitor.visit(this);  // Accept the visitor
    }
}

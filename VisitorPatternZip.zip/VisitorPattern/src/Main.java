// Main.java - Entry point to run the program
public class Main {
    public static void main(String[] args) {
        // Create a list of items (elements)
        Item[] items = {
            new RubberDuck(3.99),
            new Doll(16.50),
            new TeddyBear(8.99)
        };

        // Create visitors
        Visitor priceVisitor = new PriceVisitor();
        Visitor taxVisitor = new TaxVisitor();

        // Apply visitors to all items
        for (Item item : items) {
            item.accept(priceVisitor); // Calculate price
            item.accept(taxVisitor);   // Calculate tax
        }

        // Display the results, formatted to two decimal places
        System.out.println("Total Price: $" + String.format("%.2f", ((PriceVisitor) priceVisitor).getTotalPrice()));
        System.out.println("Total Tax: $" + String.format("%.2f", ((TaxVisitor) taxVisitor).getTotalTax()));
    }
}

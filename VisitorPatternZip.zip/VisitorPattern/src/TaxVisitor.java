// Concrete Visitor for calculating tax
public class TaxVisitor implements Visitor {
    private double totalTax = 0.0;

    @Override
    public void visit(RubberDuck rubberduck) {
        totalTax += rubberduck.getPrice() * 0.1; // Tax 10%
    }

    @Override
    public void visit(Doll doll) {
        totalTax += doll.getPrice() * 0.1; // Tax 10%
    }

    @Override
    public void visit(TeddyBear teddybear) {
        totalTax += teddybear.getPrice() * 0.1; // Tax 10%
    }

    public double getTotalTax() {
        return totalTax;
    }
}

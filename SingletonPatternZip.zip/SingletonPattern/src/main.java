public class main {
    public static void main(String[] args) {
        // Accessing the Singleton instance from a different class
        Singleton singletonInstance = Singleton.getInstance();

        // Calling the talk method to simulate conversation
        singletonInstance.talk();

        // Trying to get another instance (this will point to the same object)
        Singleton anotherInstance = Singleton.getInstance();
        
        // Verifying that both references point to the same instance
        if (singletonInstance == anotherInstance) {
            System.out.println("Both references point to the same Singleton instance.");
        }

        // Ending the conversation
        System.out.println("Goodbye, and thank you for using the Singleton pattern!");
    }
}
class Singleton {
    // 1. Private static variable to hold the only instance of the Singleton class
    private static Singleton instance;

    // 2. Private constructor to prevent instantiation
    private Singleton() {}

    // 3. Public method to provide access to the instance
    public static Singleton getInstance() {
        // Initialize the instance when it's first requested
        if (instance == null) {
            instance = new Singleton();
        }
        return instance;
    }

    public void talk() {
        System.out.println("Hello, I am the only instance of the Singleton class!");
        System.out.println("How can I assist you today?");
    }
}